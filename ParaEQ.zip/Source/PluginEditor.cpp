/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
ParametricEQAudioProcessorEditor::ParametricEQAudioProcessorEditor (ParametricEQAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (400, 300);    
    addAndMakeVisible(gainLabel);
    gainLabel.setText("Gain", juce::NotificationType::dontSendNotification);
    addAndMakeVisible(gainSlider);
 
    fcenterLabel.setText("frequency", juce::NotificationType::dontSendNotification);
    addAndMakeVisible(fcenterLabel);
    addAndMakeVisible(fcenterKnob);
    
    qLabel.setText("Q", juce::NotificationType::dontSendNotification);
    addAndMakeVisible(qLabel);
    addAndMakeVisible(qKnob);
    
    gainSlider.setSliderStyle(juce::Slider::SliderStyle::LinearVertical);
    gainSlider.setColour(juce::Slider::ColourIds::trackColourId, juce::Colours::darkviolet);
    gainSlider.setColour(juce::Slider::ColourIds::backgroundColourId, juce::Colours::white);
    gainSlider.setTextBoxStyle(juce::Slider::TextEntryBoxPosition::TextBoxBelow, false, 50, 50);
    
    //label 
  
    gainLabel.attachToComponent(&gainSlider, false);
    gainLabel.setFont(juce::Font(15.0f, juce::Font::plain));
    gainLabel.setJustificationType(juce::Justification::centred);
    gainLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    gainLabel.setColour(juce::Label::backgroundColourId, juce::Colour(juce::Colours::transparentBlack));

    //
    fcenterKnob.setSliderStyle(juce::Slider::SliderStyle::RotaryHorizontalVerticalDrag);
    fcenterKnob.setColour(juce::Slider::ColourIds::thumbColourId, juce::Colours::purple);
    fcenterKnob.setColour(juce::Slider::ColourIds::backgroundColourId, juce::Colours::white);
    fcenterKnob.setTextBoxStyle(juce::Slider::TextEntryBoxPosition::TextBoxBelow, false, 50, 50);
    //label

   
    fcenterLabel.attachToComponent(&fcenterKnob, false);
    fcenterLabel.setFont(juce::Font(15.0f, juce::Font::plain));
    fcenterLabel.setJustificationType(juce::Justification::centred);
    fcenterLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    fcenterLabel.setColour(juce::Label::backgroundColourId, juce::Colour(juce::Colours::transparentBlack));

    //
    qKnob.setSliderStyle(juce::Slider::SliderStyle::RotaryHorizontalVerticalDrag);
    qKnob.setColour(juce::Slider::ColourIds::thumbColourId, juce::Colours::purple);
    qKnob.setColour(juce::Slider::ColourIds::backgroundColourId, juce::Colours::white);
    qKnob.setTextBoxStyle(juce::Slider::TextEntryBoxPosition::TextBoxBelow, false, 50, 50);
   //Label

    
    qLabel.attachToComponent(&qKnob, false);
    qLabel.setFont(juce::Font(15.0f, juce::Font::plain));
    qLabel.setJustificationType(juce::Justification::centred);
    qLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    qLabel.setColour(juce::Label::backgroundColourId, juce::Colour(juce::Colours::transparentBlack));

   // Step 1: Use the getParameters() function to get the audio parameter tree
        
        auto parameterTree = audioProcessor.getParameters();

    /*
        Step 2: Use the function getUnchecked() to get the pointer to the specific parameter for your knob and slider and we cast it to a AudioParameterFloat
    */
    gainSliderParameter = (juce::AudioParameterFloat*)parameterTree.getUnchecked(0);
    fcenterKnobParameter = (juce::AudioParameterInt*)parameterTree.getUnchecked(1);
    qKnobParameter = (juce::AudioParameterFloat*)parameterTree.getUnchecked(2);

    /*
        Step 3: Use the function setRange() to set the Ranges of your knob and slider
    */
    gainSlider.setRange(gainSliderParameter->range.start, gainSliderParameter->range.end, gainSliderParameter->range.interval);
    auto fcenterRange = fcenterKnobParameter->getRange();
    fcenterKnob.setRange(fcenterRange.getStart(), fcenterRange.getEnd(), 1);
    qKnob.setRange(qKnobParameter->range.start, qKnobParameter->range.end, qKnobParameter->range.interval);

    /*
        Step 4: Set the default Value of the slider and knob
    */
    gainSlider.setValue(0, juce::NotificationType::dontSendNotification);
    fcenterKnob.setValue(2000, juce::NotificationType::dontSendNotification);
    qKnob.setValue(1.f, juce::NotificationType::dontSendNotification);

    /*
        Step 5 : Use the lamda function to setValue of the audio processor parameters
    */
    gainSlider.onValueChange = [this]
    {
        *gainSliderParameter = gainSlider.getValue();
    };

    fcenterKnob.onValueChange = [this]
    {
        *fcenterKnobParameter = fcenterKnob.getValue();
    };

    qKnob.onValueChange = [this]
    {
        *qKnobParameter = qKnob.getValue();
    };


}

ParametricEQAudioProcessorEditor::~ParametricEQAudioProcessorEditor()
{
}

//==============================================================================
void ParametricEQAudioProcessorEditor::paint (juce::Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));

}

void ParametricEQAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
    auto x = getWidth() / 10;
    auto y = getHeight() / 10;

    /*
        Use the setBounds() function to position the GUI Components (x,y) and set the width and height (width,height)
    */
    gainSlider.setBounds(x, y, 2 * x, 8 * y);
    fcenterKnob.setBounds(4 * x, 3 * y, 4 * x, 4 * y);
    qKnob.setBounds(7 * x, 3 * y, 4* x, 4 * y);
}
