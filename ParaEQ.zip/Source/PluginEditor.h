/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class ParametricEQAudioProcessorEditor  : public juce::AudioProcessorEditor
{
public:
    ParametricEQAudioProcessorEditor (ParametricEQAudioProcessor&);
    ~ParametricEQAudioProcessorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    ParametricEQAudioProcessor& audioProcessor;
    /*
    Declaring GUI Components Here
*/
    juce::Slider gainSlider;
    juce::Label gainLabel;
    juce::Slider fcenterKnob;
    juce::Label fcenterLabel;
    juce::Slider qKnob;
    juce::Label qLabel;
    /*
        Declaring AudioProcessor Parameters
    */
    juce::AudioParameterFloat* gainSliderParameter;
    juce::AudioParameterInt* fcenterKnobParameter;
    juce::AudioParameterFloat* qKnobParameter;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ParametricEQAudioProcessorEditor)
};
